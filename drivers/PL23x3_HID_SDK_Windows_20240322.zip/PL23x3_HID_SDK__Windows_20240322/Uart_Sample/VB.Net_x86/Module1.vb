﻿Imports System.Runtime.InteropServices

Module Module1
    Const PROLIFIC_VID As UShort = &H67B
    Const ERROR_SUCCESS As Int32 = 0
    Const ERROR_INSUFFICIENT_BUFFER As Int32 = -1
    Const ERROR_READ_REGISTER_FAIL As Int32 = -2
    Const ERROR_WRITE_REGISTER_FAIL As Int32 = -3
    Const ERROR_READ_DATA_FAIL As Int32 = -4
    Const ERROR_READ_TIMEOUT As Int32 = -5
    Const ERROR_WRITE_DATA_FAIL As Int32 = -6
    Const ERROR_WRITE_TIMEOUT As Int32 = -7
    Const ERROR_DEVICE_NOT_EXIST As Int32 = -8
    Const ERROR_NOT_GPIO_PIN As Int32 = -9
    Const ERROR_DEVICE_OPEN_FAIL As Int32 = -10
    Const ERROR_DATA_LENGTH_TOO_LARGE As Int32 = -11
    Const ERROR_OTHER_FAIL As Int32 = -12
    Const ERROR_I2C_BUS_BUSY As Int32 = -13
    Const ERROR_I2C_ADDRESS_NACK As Int32 = -14
    Const ERROR_I2C_DATA_NACK As Int32 = -15
    Const ERROR_I2C_PROCESSING As Int32 = -16

    'UART UART_FLOW_CONTROL MODE
    Enum UART_FLOW_CONTROL
        UART_RTS_CTS_DTR_DSR_FLOW_CONTROL = &H10
        UART_DTR_DSR_FLOW_CONTROL = &H14
        UART_RTS_CTS_FLOW_CONTROL = &H18
        UART_SW_FLOW_CONTROL = &HC
        UART_DISABLE_FLOW_CONTROL = &H1C
    End Enum

    'STOP BIT
    Enum UART_STOP_BIT
        UART_ONE_STOP_BIT = 0
        UART_ONE_POINT_FIVE_STOP_BIT = 1
        UART_TWO_STOP_BIT = 2
    End Enum

    'PARITY
    Enum UART_PARITY_TYPE
        UART_PARITY_NONE = 0
        UART_PARITY_ODD = 1
        UART_PARITY_EVEN = 2
        UART_PARITY_MARK = 3
        UART_PARITY_SPACE = 4
    End Enum

    'DATA BIT
    Enum UART_DATA_BIT
        UART_DATA_BIT_5 = 5
        UART_DATA_BIT_6 = 6
        UART_DATA_BIT_7 = 7
        UART_DATA_BIT_8 = 8
    End Enum

    <DllImport("HidDeviceSdk.dll")> _
    Public Function EnumDeviceByVid(ByRef HidDeviceCount As UInteger, ByVal VID As UShort) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function OpenDeviceHandle(ByVal DeviceIndex As UInteger, ByRef hDeviceHandle As IntPtr) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function CloseDeviceHandle(ByVal hDeviceHandle As IntPtr) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function UartWrite(ByVal hDeviceHandle As IntPtr, ByRef WriteBuffer As Byte, ByVal NumberOfBytesToWrite As UInteger, _
       ByRef NumberOfBytesWritten As UInteger, ByVal TimeOutms As UInteger) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function UartRead(ByVal hDeviceHandle As IntPtr, ByRef ReadBuffer As Byte, ByVal NumberOfBytesToRead As UInteger, _
                            ByRef NumberOfBytesRead As UInteger, ByVal TimeOutms As UInteger) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function SetUartConfig(ByVal hDeviceHandle As IntPtr, ByVal BaudRate As UInteger, ByVal StopBit As UART_STOP_BIT, _
                                ByVal ParityType As UART_PARITY_TYPE, ByVal Databit As UART_DATA_BIT, _
                                ByVal FlowControl As UART_FLOW_CONTROL) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function GetUartConfig(ByVal hDeviceHandle As IntPtr, ByRef BaudRate As UInteger, _
                                ByRef StopBit As UART_STOP_BIT, ByRef ParityType As UART_PARITY_TYPE, _
                                ByRef Databit As UART_DATA_BIT, ByRef FlowControl As UART_FLOW_CONTROL) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function SetXonXoffSymbol(ByVal hDeviceHandle As IntPtr, ByVal Xon As Byte, ByVal Xoff As Byte) As Int32
    End Function

    <DllImport("HidDeviceSdk.dll")> _
    Public Function UartReset(ByVal hDeviceHandle As IntPtr) As Int32
    End Function


    Sub Main()
        Dim nHidDeviceCount As UInteger = 0
        Dim hDeviceHandle As IntPtr = -1
        Dim nRet As Integer = 0
        Dim nBaudRate As UInteger = 115200     '115200 bps

        Dim nStopBit As UART_STOP_BIT = UART_STOP_BIT.UART_ONE_STOP_BIT     ' 1 Stop bit
        Dim nParityType As UART_PARITY_TYPE = UART_PARITY_TYPE.UART_PARITY_NONE     'None Parity
        Dim nDataBit As UART_DATA_BIT = UART_DATA_BIT.UART_DATA_BIT_8       ' 8 Data bit
        Dim nFlowControl As UART_FLOW_CONTROL = UART_FLOW_CONTROL.UART_DISABLE_FLOW_CONTROL 'No Flow Control
        nRet = EnumDeviceByVid(nHidDeviceCount, PROLIFIC_VID)
        'Step1: Enum Device (&067B ==> USB VID)
        If ERROR_SUCCESS = nRet Then
            If 0 < nHidDeviceCount Then
                'Step2: Open Hid Device Array index, ex: 0
                nRet = OpenDeviceHandle(0, hDeviceHandle)
                If ERROR_SUCCESS = nRet Then
                    'Step3: Set Uart Config
                    nRet = SetUartConfig(hDeviceHandle, nBaudRate, nStopBit, nParityType, nDataBit, nFlowControl)
                    If ERROR_SUCCESS = nRet Then
                        Console.WriteLine("SetUartConfig Success!")
                    Else
                        Console.WriteLine("SetUartConfig Fail!")
                    End If

                    Dim byWriteBuffer() As Byte = {&H30, &H31, &H32, &H33, &H34}
					Dim nNumberOfBytesToRead As UInteger = 5
                    Dim byReadBuffer(5) As Byte
                    Dim nNumberOfBytesToWrite As UInteger = 5
                    Dim nNumberOfBytesWritten As UInteger = 0
                    Dim nTimeOutms As ULong = 8 '8 ms

                    'Step4: Write
                    If ERROR_SUCCESS = UartWrite(hDeviceHandle, byWriteBuffer(0), nNumberOfBytesToWrite, _
                                                nNumberOfBytesWritten, nTimeOutms) Then
                        Console.Write("Write Uart Data: ")
                        For n As Integer = 0 To 4
                            Console.Write("0x{0:X} ", byWriteBuffer(n))
                        Next
                        Console.WriteLine("")
                    Else
                        Console.WriteLine("Write Uart Data Fail!")
                    End If

                    'Step5: Read
                    Dim nNumberOfBytesRead As UInteger = 0
                    If ERROR_SUCCESS = UartRead(hDeviceHandle, byReadBuffer(0), nNumberOfBytesToRead, _
                                                nNumberOfBytesRead, nTimeOutms) Then
                        Console.Write("Read Uart Data: ")
                        For n As Integer = 0 To 4
                            Console.Write("0x{0:X} ", byReadBuffer(n))
                        Next
                        Console.WriteLine("")
                    Else
                        Console.WriteLine("Read Uart Data Fail!")
                    End If
                    'Step6: Close Hid Device
                    nRet = CloseDeviceHandle(hDeviceHandle)
                Else
                    Console.WriteLine("Open Device Fail!")
                End If
            Else
                Console.WriteLine("No match Hid device!")
            End If
        Else
            Console.WriteLine("EnumDeviceByVid fail")
        End If
        Console.ReadLine()
    End Sub

End Module
